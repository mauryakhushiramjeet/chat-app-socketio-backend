/*
  Warnings:

  - You are about to drop the column `status` on the `GroupMessage` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "GroupMessage" DROP COLUMN "status";
